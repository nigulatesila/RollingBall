/**
  ******************************************************************************
2017ȫ����ѧ��������ƾ���ȫ��һ�Ƚ� B��
���ϿƼ���ѧ ��Ϣ����ѧԺ 
�żұ� ��ľ���� ����Ӱ
  ******************************************************************************
  */
  /*
	pwm   A8  A0
	����	A4  A5
	
	
	*/
#include "stm32f10x.h"
#include "./ov7725/bsp_ov7725.h"
#include "./lcd/bsp_ili9341_lcd.h"
#include "./led/bsp_led.h" 
#include "./delay/delay.h"   
#include "./usart/bsp_usart.h"
#include "./key/bsp_key.h"  
#include "./systick/bsp_SysTick.h"
#include "bsp_pwm_output.h"
#include "control.h"
#include "sys.h" 
extern uint8_t Ov7725_vsync;
extern uint16_t moto_1,moto_2;
unsigned int Task_Delay[NumOfTask]; 
int step[12]={
				7,7,7,
				7,7,7,
				7,7,7,
				7,7,7};
int time=0;
int test=0;
int W=15;
uint8_t mid[10]={0x0F,0x1F,0x2F,0x3F,0x4F,0x5F,0x6F,0x7F,0x8F,0x9F};
int key_b[4]={0};
int kkk;
int mid_choose=5;
uint8_t mid_line;
extern OV7725_MODE_PARAM cam_mode;


int adr[26]=	{	
				201,201,	118,202,	34,201, //123
				202,120,	118,118,	36,117,//456
				200,38,		122,36,		38,34,//789
					159,160,          76,159,
					160,78,            79,76
};
/**
  * @brief  ������
  * @param  ��  
  * @retval ��
  */
void Delay(__IO uint32_t nCount)	 //�򵥵���ʱ����Delay(0x0FFFFF);
{
	for(; nCount != 0; nCount--);
}
void pint_nine(  int  *adr1)
{int i1=0;
	for(i1=0;i1<18;i1+=2)
	ILI9341_DrawCircle ( adr1[i1],adr1[i1+1],3,0 );

}
void pint_wait(int W)
{	
	char ti[10][4]={"0","1","2","3","4","5","6","7","8","9"};
	ILI9341_GramScan ( 3 );	
	W=(W>100)?99:W;
	W=(W<0)?0:W;
	ILI9341_DispString_EN(0,220,"W=");
	ILI9341_DispString_EN(25,220,ti[W/10]);
	ILI9341_DispString_EN(35,220,ti[W%10]);
	ILI9341_GramScan ( 5 );

}
void pint_mid(  int  mid)
{
	char ti[10][4]={"0","1","2","3","4","5","6","7","8","9"};
	ILI9341_GramScan ( 3 );	
	
	 	ILI9341_DispString_EN(00,60,"MID =");
	ILI9341_DispString_EN(40,60,"0x");
	ILI9341_DispString_EN(60,60,ti[mid]);
		ILI9341_DispString_EN(70,60,"F");

	ILI9341_GramScan ( 5 );

}
void pint_12(  int  *step)
{
	char ti[14][4]={"0 ","1 ","2 ","3 ","4 ","5 ","6 ","7 ","8 ","9 ","10","11","12","13"};
		ILI9341_GramScan ( 3 );	
	
		ILI9341_DispString_EN(00,80,"exam2:");
	 	ILI9341_DispString_EN(00,100,ti[step[0]]);
		ILI9341_DispString_EN(25,100,ti[step[1]]);
		ILI9341_DispString_EN(50,100,ti[step[2]]);
	
		ILI9341_DispString_EN(00,120,ti[step[3]]);
	 	ILI9341_DispString_EN(25,120,ti[step[4]]);
		ILI9341_DispString_EN(50,120,ti[step[5]]);
	
		ILI9341_DispString_EN(00,140,ti[step[6]]);
		ILI9341_DispString_EN(25,140,ti[step[7]]);
		ILI9341_DispString_EN(50,140,ti[step[8]]);
	
		ILI9341_DispString_EN(00,160,ti[step[9]]);
		ILI9341_DispString_EN(25,160,ti[step[10]]);
		ILI9341_DispString_EN(50,160,ti[step[11]]);

		ILI9341_GramScan ( 5 );

}
void pint_text(  int  text)
{
	char ti[10][4]={"0","1","2","3","4","5","6","7","8","9"};
	ILI9341_GramScan ( 3 );	
	ILI9341_DispString_EN(00,40,"TEXT=");
	ILI9341_DispString_EN(60,40,ti[text]);
	ILI9341_GramScan ( 5 );

}
void pint_key(  int * KEY)
{	int i;
	char ti[10][4]={"0","1","2","3","4","5","6","7","8","9"};
	ILI9341_GramScan ( 3 );	
	
	ILI9341_DispString_EN(00,180,"KEY=");
	
	ILI9341_DispString_EN(0,200,ti[KEY[0]]);
	ILI9341_DispString_EN(20,200,ti[KEY[1]]);
	
	ILI9341_DispString_EN(40,200,ti[KEY[2]]);
	ILI9341_DispString_EN(60,200,ti[KEY[3]]);
	ILI9341_GramScan ( 5 );

}
void pint_time(  int  time)
{
	time=time/10;
	time=(time>100000)?99999:time;
	time=(time<0)?0:time;
	char ti[10][4]={"0","1","2","3","4","5","6","7","8","9"};
	LCD_SetTextColor(RED);
	ILI9341_GramScan ( 3 );	
	
	ILI9341_DispString_EN(60,20,"s");
	 ILI9341_DispString_EN(50,20,ti[time%10]);
	 ILI9341_DispString_EN(40,20,ti[time%100/10]);
	 ILI9341_DispString_EN(30,20,".");
	 ILI9341_DispString_EN(20,20,ti[time%1000/100]);
	 ILI9341_DispString_EN(10,20,ti[time%10000/1000]);
	 ILI9341_DispString_EN(0 ,20,ti[time%100000/10000]);

	ILI9341_GramScan ( 5 );

}
void pint(void)
{	
		key_b[0]=key_1;
		key_b[1]=key_2;
		key_b[2]=key_3;
		key_b[3]=key_4;
	
		pint_key(key_b);
		pint_nine( adr);
		pint_time(time);
		pint_text(test);
		pint_mid(mid_choose);
		pint_12(step);
		pint_wait(W);
}
int main(void) 	
{		
	int input;
	uint8_t retry = 0;

	/* Һ����ʼ�� */
	ILI9341_Init();
	ILI9341_GramScan ( 3 );
	
	LCD_SetFont(&Font8x16);
	LCD_SetColors(RED,BLACK);

  ILI9341_Clear(0,0,LCD_X_LENGTH,LCD_Y_LENGTH);	/* ��������ʾȫ�� */
	
	/********��ʾ�ַ���ʾ��*******/
  ILI9341_DispStringLine_EN(LINE(0),"TIME=");
	USART_Config();
	TIM1_2_PWM_Init();
	MOTOR_IO_Init();
  KEY_IO_Init();
	TIM1_NVIC_Configuration();
	TIM2_NVIC_Configuration();
	SysTick_Init(); 
	
	/* ov7725 gpio ��ʼ�� */
	OV7725_GPIO_Config();
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1 , ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2 , ENABLE);
	/* ov7725 �Ĵ���Ĭ�����ó�ʼ�� */
	while(OV7725_Init() != SUCCESS)
	{
		retry++;
		if(retry>5)
		{
			printf("\r\nû�м�⵽OV7725����ͷ\r\n");
			ILI9341_DispStringLine_EN(LINE(2),"No OV7725 module detected!");
			while(1);
		}
	}


	/*��������ͷ����������ģʽ*/
	OV7725_Special_Effect(cam_mode.effect);
	/*����ģʽ*/
	OV7725_Light_Mode(cam_mode.light_mode);
	/*���Ͷ�*/
	OV7725_Color_Saturation(cam_mode.saturation);
	/*���ն�*/
	OV7725_Brightness(cam_mode.brightness);
	/*�Աȶ�*/
	OV7725_Contrast(cam_mode.contrast);
	/*����Ч��*/
	OV7725_Special_Effect(cam_mode.effect);
	
	/*����ͼ�������ģʽ��С*/
	OV7725_Window_Set(cam_mode.cam_sx,
														cam_mode.cam_sy,
														cam_mode.cam_width,
														cam_mode.cam_height,
														cam_mode.QVGA_VGA);

	/* ����Һ��ɨ��ģʽ */
	ILI9341_GramScan( cam_mode.lcd_scan );
	
	
	Ov7725_vsync = 0;
	pint_12(step);
	Delay(0x0FFFFF);
	input=0;
	
		
	pint();
	kkk=key_4;
	if(key_1==0&&key_2==1&&key_3==0)
	{
		
		while(input<13)
		{	
			if(key_5==0&&step[input]<13){step[input]++;}
			if(key_6==0&&step[input]>1){step[input]--;}
			Delay(0x0FFFFF);
			if(key_7==0)input++;
	pint();
		
		}
	}
	
	while(key_4==kkk)//���뿪��4����ȥ��������
	{
	
		pint();
		mid_line=mid[mid_choose];
		if(key_5==0&&mid_choose<10){mid_choose++;mid_line=mid[mid_choose];}
		if(key_6==0&&mid_choose>0){mid_choose--;mid_line=mid[mid_choose];}
		Delay(0x0FFFFF);
		if( Ov7725_vsync == 2 )
		{
			FIFO_PREPARE;  			/*FIFO׼��*/					
			ImagDisp(cam_mode.lcd_sx,
								cam_mode.lcd_sy,
								cam_mode.cam_width,
								cam_mode.cam_height);			/*�ɼ�����ʾ*/
			
			Ov7725_vsync = 0;			
		}
	}	
	


	time=0;pint();
	while(1)
	{
	pint_time(time);
		pint_nine( adr);
		/*���յ���ͼ�������ʾ*/
		if( Ov7725_vsync == 2 )
		{
			FIFO_PREPARE;  			/*FIFO׼��*/					
			ImagDisp(cam_mode.lcd_sx,
								cam_mode.lcd_sy,
								cam_mode.cam_width,
								cam_mode.cam_height);			/*�ɼ�����ʾ*/
			
			Ov7725_vsync = 0;			
		}
}

}


/*********************************************END OF FILE**********************/

