#ifndef __PWM_OUTPUT_H
#define	__PWM_OUTPUT_H
#include "sys.h" 
#include "stm32f10x.h"
void TIM1_Mode_Config(void);
void TIM1_2_PWM_Init(void);
void TIM2_Mode_Config(void);
void Timer3_Init(u16 arr,u16 psc);  
void TIM1_NVIC_Configuration(void);
void TIM2_NVIC_Configuration(void);
#endif /* __PWM_OUTPUT_H */
