#ifndef __CONTROL_H
#define __CONTROL_H
#include "stm32f10x.h"
void set_position(int step_x,int step_y,int target_x,int target_y);
void balance_control(int x,int y);
void MyTimer1_Startup(int num,int frequency);
void MyTimer2_Startup(int num,int frequency);
int myabs(int a);
void Set_Pwm(int moto1,int moto2);
void test_1(int step_x,int step_y);
void test_2(int step_x,int step_y);
void test_3(int step_x,int step_y);
void test_4(int step_x,int step_y);
void exam_1(int step_x,int step_y);
void exam_2(int step_x,int step_y);
void exam_3(int step_x,int step_y);
void exam_4(int step_x,int step_y);
int test_choose(int step_x,int step_y);
/****************************/

/****************************/
#endif




