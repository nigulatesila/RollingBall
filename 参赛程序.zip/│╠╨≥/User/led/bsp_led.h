#ifndef __LED_H
#define	__LED_H

#include "sys.h" 
#include "stm32f10x.h"



#define AIN_1     PAout(4)
#define BIN_1     PAout(5)

#define key_1     PCin(8)
#define key_2     PCin(9)
#define key_3     PCin(10)
#define key_4     PCin(11)
#define key_5     PCin(12)
#define key_6     PCin(13)
#define key_7     PCin(14)

void MOTOR_IO_Init(void);
void KEY_IO_Init(void);
#endif /* __LED_H */
