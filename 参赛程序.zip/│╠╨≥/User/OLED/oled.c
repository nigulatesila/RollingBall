#include "oled.h"
#include "myiic.h"
#include "delay.h"
#include "zifu.h"
u8 OLED_GRAM[128][8];	
void OLED_Init(void)
{
	IIC_Init();
	delay_ms(500);//��ʼ��֮ǰ����ʱ����Ҫ��
	OLED_WrCmd(0xae);//--turn off oled panel
	OLED_WrCmd(0x00);//---set low column address
	OLED_WrCmd(0x10);//---set high column address
	OLED_WrCmd(0x40);//--set start line address  Set Mapping RAM Display Start Line (0x00~0x3F)
	OLED_WrCmd(0x81);//--set contrast control register
	OLED_WrCmd(Brightness); // Set SEG Output Current Brightness
	OLED_WrCmd(0xa1);//--Set SEG/Column Mapping     0xa0���ҷ��� 0xa1����
	OLED_WrCmd(0xc8);//Set COM/Row Scan Direction   0xc0���·��� 0xc8����
	OLED_WrCmd(0xa6);//--set normal display
	OLED_WrCmd(0xa8);//--set multiplex ratio(1 to 64)
	OLED_WrCmd(0x3f);//--1/64 duty
	OLED_WrCmd(0xd3);//-set display offset	Shift Mapping RAM Counter (0x00~0x3F)
	OLED_WrCmd(0x00);//-not offset
	OLED_WrCmd(0xd5);//--set display clock divide ratio/oscillator frequency
	OLED_WrCmd(0x80);//--set divide ratio, Set Clock as 100 Frames/Sec
	OLED_WrCmd(0xd9);//--set pre-charge period
	OLED_WrCmd(0xf1);//Set Pre-Charge as 15 Clocks & Discharge as 1 Clock
	OLED_WrCmd(0xda);//--set com pins hardware configuration
	OLED_WrCmd(0x12);
	OLED_WrCmd(0xdb);//--set vcomh
	OLED_WrCmd(0x40);//Set VCOM Deselect Level
	OLED_WrCmd(0x20);//-Set Page Addressing Mode (0x00/0x01/0x02)
	OLED_WrCmd(0x02);//
	OLED_WrCmd(0x8d);//--set Charge Pump enable/disable
	OLED_WrCmd(0x14);//--set(0x10) disable
	OLED_WrCmd(0xa4);// Disable Entire Display On (0xa4/0xa5)
	OLED_WrCmd(0xa6);// Disable Inverse Display On (0xa6/a7) 
	OLED_WrCmd(0xaf);//--turn on oled panel
	OLED_Fill(0x00); //��ʼ����
	OLED_Set_Pos(0,0);
}



void OLED_Wrdat(u8 dat)				//д����
{
	IIC_Start();
	IIC_Send_Byte(0x78);		//������ַ
	IIC_Wait_Ack();
	IIC_Send_Byte(0x40);		//д����
	IIC_Wait_Ack();
	IIC_Send_Byte(dat);
	IIC_Wait_Ack();
	IIC_Stop();
}


void OLED_WrCmd(u8 Command)		//д����
{
	IIC_Start();
	IIC_Send_Byte(0x78);
	IIC_Wait_Ack();
	IIC_Send_Byte(0x00);
	IIC_Wait_Ack();
	IIC_Send_Byte(Command);
	IIC_Wait_Ack();
	IIC_Stop();
}


void OLED_Set_Pos(u8 x,u8 y)		//��������
{
	OLED_WrCmd(0xb0+y);
	OLED_WrCmd(((x&0xf0)>>4)|0x10);
	OLED_WrCmd((x&0x0f)|0x01);
}


void OLED_Fill(u8 bmp_dat)			//ȫ����	
{
	u8 x,y;
	for(y = 0; y < 8; y++)
	{
		OLED_WrCmd(0xb0+y);
		OLED_WrCmd(0x01);
		OLED_WrCmd(0x10);
		for(x = 0; x < X_WIDTH; x++)
		{
			OLED_Wrdat(bmp_dat);
		}
	}
}

void OLED_RESET(void)					//��λ
{
	u8 y,x;
	for(y = 0; y < 8; y++)
	{
		OLED_WrCmd(0xb0 + y);
		OLED_WrCmd(0x01);
		OLED_WrCmd(0x10);
		for(x = 0; x < X_WIDTH; x++)
		OLED_Wrdat(0);
	}
}




void OLED_P12x16num(u8 x, u8 y, u8 num)
{
		u8 i = 0; 
		if (x > 116)
		{
			x = 0;
			y++;
		}
		OLED_Set_Pos(x,y);
		for(i=0;i<12;i++)
	{
		OLED_Wrdat(NUM12x16[num*24+i]);
	}
	OLED_Set_Pos(x,y+1);
	for(i=0;i<12;i++)
	{
		OLED_Wrdat(NUM12x16[num*24+i+12]);
	}
}


void OLED_P16x24num(u8 x, u8 y, u8 num)
{
	u8 i=0;

	if(x>112){x=0;y++;}
	OLED_Set_Pos(x,y);
	for(i=0;i<16;i++)
	{
		OLED_Wrdat(NUM16x24[num*48+i]);
	}
	OLED_Set_Pos(x,y+1);
	for(i=0;i<16;i++)
	{
		OLED_Wrdat(NUM16x24[num*48+i+16]);
	}
	OLED_Set_Pos(x,y+2);
	for(i=0;i<16;i++)
	{
		OLED_Wrdat(NUM16x24[num*48+i+32]);
	}
	
}
void OLED_P16_24Str(u8 x,u8 y,u8 ch[])
{
	u8 c = 0, i = 0, j = 0;
	
	while (ch[j]!='\0')
	{
		c = ch[j] - 65;
		if(x>112){x=0;y++;}
		OLED_Set_Pos(x,y);
		for(i=0;i<16;i++)
		{
			OLED_Wrdat(F16x24[c*48+i]);
		}
		OLED_Set_Pos(x,y+1);
		for(i=0;i<16;i++)
		{
			OLED_Wrdat(F16x24[c*48+i+16]);
		}
		OLED_Set_Pos(x,y+2);
		for(i=0;i<16;i++)
		{
			OLED_Wrdat(F16x24[c*48+i+32]);
		}
			x+=16;
			j++;
	}
}


void OLED_P16x16num(unsigned char x, unsigned char y,unsigned char N)
{
	unsigned char wm=0;
	unsigned int adder=16*N;
	OLED_Set_Pos(x , y);
	for(wm = 0;wm < 8;wm++)
	{
		OLED_Wrdat(NUM16x16[adder]);
		adder += 1;
	}
	OLED_Set_Pos(x,y + 1);
	for(wm = 0;wm < 8;wm++)
	{
		OLED_Wrdat(NUM16x16[adder]);
		adder += 1;
	} 	  	
}
void OLED_DrawPoint(u8 x,u8 y,u8 t)
{
   u8 pos,bx,temp=0;
   if(x>127||y>63)return;//?????.
   pos=7-y/8;
   bx=y%8;
   temp=1<<(7-bx);
   if(t)OLED_GRAM[x][pos]|=temp;
   else OLED_GRAM[x][pos]&=~temp;	    
}
void OLED_Refresh_Gram(void)
{
	u8 i,n;		    
	for(i=0;i<8;i++)  
	{  
		OLED_WrCmd(0xb0+i);
			OLED_WrCmd(((0xf0)>>4)|0x10);
			OLED_WrCmd((0x0f)|0x01);
		for(n=0;n<128;n++)OLED_Wrdat(OLED_GRAM[n][i]); 
	}   
}

